class Subscription {
  String? name, avatar, description;

  Subscription({
    this.name,
    this.avatar,
    this.description,
  });

  Subscription.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    avatar = json['owner']['avatar_url'];
    description = json['description'];
  }
}