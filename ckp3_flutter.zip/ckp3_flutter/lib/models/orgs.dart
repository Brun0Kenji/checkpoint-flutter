class Organization {
  String? name, avatar, description;

  Organization({
    this.name,
    this.avatar,
    this.description,
  });

  Organization.fromJson(Map<String, dynamic> json) {
    name = json['login'];
    avatar = json['avatar_url'];
    description = json['description'];
  }
}
