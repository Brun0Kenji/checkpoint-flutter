import 'package:flutter/material.dart';

import '../api/github_api.dart';
import '../models/user.dart';
import '../models/repos.dart';
import '../models/orgs.dart';
import '../models/subs.dart';

class UserPage extends StatefulWidget {
  final User user;
  const UserPage({required this.user});

  @override
  State<UserPage> createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  final api = GitHubApi();
  late Future<List<User>> _futureFollowings;
  late Future<List<Repository>> _futureRepos;
  late Future<List<Organization>> _futureOrgs;
  late Future<List<Subscription>> _futureSubs;
  int currentPageIndex = 0;

  @override
  void initState() {
    _futureFollowings = api.getFollowing(widget.user.login);
    _futureRepos = api.getRepos(widget.user.login);
    _futureOrgs = api.getOrgs(widget.user.login);
    _futureSubs = api.getSubs(widget.user.login);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: NavigationBar(
        onDestinationSelected: (int index) {
          setState(() {
            currentPageIndex = index;
          });
        },
        indicatorColor: Colors.blue,
        selectedIndex: currentPageIndex,
        destinations: const <Widget>[
          NavigationDestination(
            selectedIcon: Icon(Icons.person),
            icon: Icon(Icons.person_outline),
            label: 'User',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.group),
            icon: Icon(Icons.group_outlined),
            label: 'Following',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.book),
            icon: Icon(Icons.book_outlined),
            label: 'Repos',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.group_work),
            icon: Icon(Icons.group_work_outlined),
            label: 'Orgs',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.subscriptions),
            icon: Icon(Icons.subscriptions_outlined),
            label: 'Subs',
          ),
        ],
      ),
      body: <Widget>[
        Container(
          alignment: Alignment.center,
          child: Column(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    const SizedBox(
                      height: 50,
                    ),
                    SizedBox(
                      width: 120,
                      height: 120,
                      child: CircleAvatar(
                        radius: 50.0,
                        backgroundColor: Colors.transparent,
                        backgroundImage: NetworkImage(widget.user.avatarUrl),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      widget.user.login,
                      style: TextStyle(fontSize: 22),
                    ),
                    const SizedBox(
                      height: 150,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          alignment: Alignment.center,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircleAvatar(
                      radius: 50.0,
                      backgroundColor: Colors.transparent,
                      backgroundImage: NetworkImage(widget.user.avatarUrl),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    widget.user.login,
                    style: TextStyle(fontSize: 22),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
                child: FutureBuilder<List<User>>(
              future: _futureFollowings,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  var followings = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: followings.length,
                    itemBuilder: ((context, index) {
                      var user = followings[index];
                      return ListTile(
                        leading: CircleAvatar(
                            backgroundImage: NetworkImage(user.avatarUrl)),
                        title: Text(user.login),
                        trailing: const Text(
                          "Following",
                          style: TextStyle(color: Colors.blueAccent),
                        ),
                      );
                    }),
                  );
                }
              },
            ))
          ]),
        ),
        Container(
          alignment: Alignment.center,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircleAvatar(
                      radius: 50.0,
                      backgroundColor: Colors.transparent,
                      backgroundImage: NetworkImage(widget.user.avatarUrl),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    widget.user.login,
                    style: TextStyle(fontSize: 22),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
                child: FutureBuilder<List<Repository>>(
              future: _futureRepos,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  var repos = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: repos.length,
                    itemBuilder: ((context, index) {
                      var repository = repos[index];
                      return ListTile(
                        dense: true,
                        title: Text(
                          repository.name.toString(),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(repository.description.toString()),
                        leading: CircleAvatar(
                          radius: 48.0,
                          backgroundImage:
                              NetworkImage(repository.avatar.toString()),
                        ),
                      );
                    }),
                  );
                }
              },
            ))
          ]),
        ),
        Container(
          alignment: Alignment.center,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircleAvatar(
                      radius: 50.0,
                      backgroundColor: Colors.transparent,
                      backgroundImage: NetworkImage(widget.user.avatarUrl),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    widget.user.login,
                    style: TextStyle(fontSize: 22),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
                child: FutureBuilder<List<Organization>>(
              future: _futureOrgs,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  var organizations = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: organizations.length,
                    itemBuilder: ((context, index) {
                      var orgs = organizations[index];
                      return ListTile(
                        dense: true,
                        title: Text(
                          orgs.name.toString(),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(orgs.description.toString()),
                        leading: CircleAvatar(
                          radius: 48.0,
                          backgroundImage: NetworkImage(orgs.avatar.toString()),
                        ),
                      );
                    }),
                  );
                }
              },
            ))
          ]),
        ),
        Container(
          alignment: Alignment.center,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircleAvatar(
                      radius: 50.0,
                      backgroundColor: Colors.transparent,
                      backgroundImage: NetworkImage(widget.user.avatarUrl),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    widget.user.login,
                    style: TextStyle(fontSize: 22),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
                child: FutureBuilder<List<Subscription>>(
              future: _futureSubs,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  var subscriptions = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: subscriptions.length,
                    itemBuilder: ((context, index) {
                      var subs = subscriptions[index];
                      return ListTile(
                        dense: true,
                        title: Text(
                          subs.name.toString(),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(subs.description.toString()),
                        leading: CircleAvatar(
                          radius: 48.0,
                          backgroundImage: NetworkImage(subs.avatar.toString()),
                        ),
                      );
                    }),
                  );
                }
              },
            ))
          ]),
        ),
      ][currentPageIndex],
    );
  }
}
